import React from 'react';

function Cart() {
  return (
    <div className="container mt-5 text-center">
      <h2>Your Cart</h2>
      <p className="text-muted">You haven’t added any books yet.</p>
    </div>
  );
}

export default Cart;
